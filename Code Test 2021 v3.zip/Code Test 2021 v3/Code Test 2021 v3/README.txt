Choose ONE of the following tasks.
Please do not invest more than 2-4 hours on this.
Upload your results to a Github repo, for easier sharing and reviewing.

Thank you and good luck!



Code to refactor
=================
1) app/Http/Controllers/BookingController.php
2) app/Repository/BookingRepository.php

Code to write tests
=====================
3) App/Helpers/TeHelper.php method willExpireAt
4) App/Repository/UserRepository.php, method createOrUpdate


----------------------------

What I expect in your repo.

1, A readme with:   Your thoughts about the code. What makes it amazing code.
 Or what makes it ok code. Or what makes it terrible code. How would you have done it. Thoughts on formatting. Logic..

2.  Refactor it if you feel it needs refactoring. The more love you put into it.
The easier for us to asses.

Make two commits. First commit with original code.
Second with your refactor so we can easily trace changes.

NB: you do not need to set up the code on local and make the web app run.
 It will not run as its not a complete web app.
 This is purely to assess you thoughts about code, formatting, logic etc



============================= COMMENTS =====================================
The only good thing about code is it's using repositories pattern for dependency injection
 rest Code is very awful and hard to read.

There are a lot of if else statements which is not a very good way to code.
Most functions are too big when i code i make sure a function should not exceed 35 to 40 lines.
It's very hard to read this code i can't refactor it in short time.
We should query DB instead calculation on php side.